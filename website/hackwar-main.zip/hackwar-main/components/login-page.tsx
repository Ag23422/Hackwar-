"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import Hyperspeed from "./hyperspeed"

export default function LoginPage() {
  const router = useRouter()
  const { auth, login } = useAuth()
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await login(username, password)
    if (auth.isAuthenticated) {
      router.push("/dashboard")
    }
  }

  return (
    <div className="relative min-h-screen w-full bg-black overflow-hidden">
      <div className="absolute inset-0 z-0">
        <Hyperspeed />
      </div>

      <div className="relative z-10 flex min-h-screen items-center justify-center">
        <div className="w-full max-w-md space-y-8 rounded-lg bg-black/80 p-8 backdrop-blur-sm">
          <div className="text-center">
            <h1 className="text-4xl font-bold tracking-tight text-white">SAV</h1>
            <p className="mt-2 text-gray-400">Automated Drone Delivery System</p>
          </div>

          <form onSubmit={handleSubmit} className="mt-8 space-y-6">
            <div className="space-y-4">
              <div>
                <label htmlFor="username" className="sr-only">
                  Username
                </label>
                <Input
                  id="username"
                  name="username"
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Username"
                  className="bg-gray-900/50 border-gray-800 text-white placeholder:text-gray-400"
                />
              </div>
              <div>
                <label htmlFor="password" className="sr-only">
                  Password
                </label>
                <Input
                  id="password"
                  name="password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password"
                  className="bg-gray-900/50 border-gray-800 text-white placeholder:text-gray-400"
                />
              </div>
            </div>

            {auth.error && <p className="text-sm text-red-500">{auth.error}</p>}

            <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white" disabled={auth.isLoading}>
              {auth.isLoading ? "Signing in..." : "Sign in"}
            </Button>
          </form>
        </div>
      </div>
    </div>
  )
}

