"use client"

import { useState } from "react"
import { AuthContext, type AuthState } from "@/lib/auth-context"

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [auth, setAuth] = useState<AuthState>({
    isAuthenticated: false,
    isLoading: false,
  })

  const login = async (username: string, password: string) => {
    setAuth({ ...auth, isLoading: true, error: undefined })

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))

    if (username === "SAV" && password === "SAV123") {
      setAuth({ isAuthenticated: true, isLoading: false })
    } else {
      setAuth({
        isAuthenticated: false,
        isLoading: false,
        error: "Invalid credentials",
      })
    }
  }

  const logout = () => {
    setAuth({ isAuthenticated: false, isLoading: false })
  }

  return <AuthContext.Provider value={{ auth, login, logout }}>{children}</AuthContext.Provider>
}

