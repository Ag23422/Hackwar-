import { createContext, useContext } from "react"

export interface AuthState {
  isAuthenticated: boolean
  isLoading: boolean
  error?: string
}

export const AuthContext = createContext<{
  auth: AuthState
  login: (username: string, password: string) => Promise<void>
  logout: () => void
}>({
  auth: { isAuthenticated: false, isLoading: false },
  login: async () => {},
  logout: () => {},
})

export const useAuth = () => useContext(AuthContext)

