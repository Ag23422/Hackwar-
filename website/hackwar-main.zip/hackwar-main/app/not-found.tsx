import Link from "next/link"

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-black">
      <div className="text-center space-y-4">
        <h2 className="text-4xl font-bold text-white">404 - Not Found</h2>
        <p className="text-gray-400">Could not find the requested resource</p>
        <Link href="/" className="text-blue-500 hover:text-blue-400">
          Return Home
        </Link>
      </div>
    </div>
  )
}

