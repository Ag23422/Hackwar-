"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { LogOut } from "lucide-react"

export default function DashboardPage() {
  const router = useRouter()
  const { auth, logout } = useAuth()

  useEffect(() => {
    if (!auth.isAuthenticated) {
      router.push("/")
    }
  }, [auth.isAuthenticated, router])

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  return (
    <div className="min-h-screen bg-gray-900">
      <header className="border-b border-gray-800 bg-gray-950">
        <div className="flex h-16 items-center justify-between px-4">
          <h1 className="text-xl font-bold text-white">SAV Dashboard</h1>
          <Button variant="ghost" onClick={handleLogout} className="text-gray-400 hover:text-white">
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </div>
      </header>

      <main className="grid h-[calc(100vh-4rem)] grid-cols-2 gap-4 p-4">
        <div className="rounded-lg bg-gray-950 p-4">
          <h2 className="mb-4 text-lg font-semibold text-white">Live Drone Feed</h2>
          <div className="relative aspect-video w-full overflow-hidden rounded-lg bg-black">
            <img
              src="/placeholder.svg?height=720&width=1280"
              alt="Drone Camera Feed"
              className="h-full w-full object-cover"
            />
          </div>
        </div>

        <div className="rounded-lg bg-gray-950 p-4">
          <h2 className="mb-4 text-lg font-semibold text-white">Live Location</h2>
          <div className="relative aspect-video w-full overflow-hidden rounded-lg bg-black">
            <div className="flex h-full items-center justify-center text-gray-500">Map View</div>
          </div>
        </div>
      </main>
    </div>
  )
}


